<tr>
	<td style="padding:10px 0;"><input type="text" name="qc_param[]" id="qc_param-<?php echo $count; ?>"></td>
	<td style="padding:10px 0;"><input type="text" name="qc_value[]" id="qc_value-<?php echo $count; ?>"></td>
</tr>