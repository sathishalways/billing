<?php 
class tax extends CI_Controller{

    function __construct(){
     parent::__construct();
    $this->load->helper('url');
    $this->load->model('Tax_model');

    }
    
    
    public function add_tax(){
		
        $tax_name=$this->input->post('tax_name');
		$percentage=$this->input->post('percentage');
        $c=$tax_name;
		$count=count($c); 
		
			for($i=0; $i<$count; $i++) {
				if($tax_name[$i]!=""){ 
					$data1 = array('tax_name' => $tax_name[$i], 'tax_percentage' => $percentage[$i]);
					$result=$this->Tax_model->add_tax($data1);
				}
				else{
					echo "<script>window.location.href='".base_url()."pages/tax_list';alert('Please enter Tax');</script>";
					
				}
			}
		if(isset($result)){
			echo "<script>window.location.href='".base_url()."pages/tax_list';alert('Tax added');</script>";
		}
    }
    
	public function update_tax(){ 
		  $id=$this->input->post('id');
		  
		 $data=array(
            'tax_name'=>$this->input->post('tax_name'),
			'tax_percentage'=>$this->input->post('tax_percent')
        );
		 $s = $this->Tax_model->update_tax_info($data,$id);
		
    }
	
	public function update_default(){ 
		  $id=$this->input->post('id');
		
		 $data=array(
            'tax_default'=>$this->input->post('tax_default')
        );
		 $s = $this->Tax_model->update_tax_default($data,$id);
		
    }
	  
   
	public function del_tax(){ 
		 $id=$this->input->post('id');
		 $s = $this->Tax_model->del_tax_info($id);
    }
    
}