<?php 
class Order_model extends CI_Model{
function __construct(){
parent::__construct();
$this->load->database();
}
    public function add_orders($data){
     $this->db->insert('orders',$data);
	 return $this->db->insert_id();
      
    }
	
	public function add_order_details($data1){
		$this->db->insert('order_details',$data1); 
    }
	
	public function prod_cat_dropdownlist(){
        $this->db->select("id,product_category",FALSE);
		$this->db->from('prod_category'); 
		$query = $this->db->get();
        return $query->result();
    }
	public function serial_cnt(){
		$this->db->select("serial_no",FALSE);
		$this->db->from('order_details'); 
		$this->db->like('serial_no', 'DUM'); 
		$this->db->order_by('serial_no', 'desc'); 
		$this->db->limit(1);	
		$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
		return $query->result();
    }
	public function prod_sub_cat_dropdownlist(){
		$this->db->select("id,prod_category_id,subcat_name",FALSE);
		$this->db->from('prod_subcategory'); 
		$query = $this->db->get();
        return $query->result();
    }
	
	public function brandlist(){
		$this->db->select("id, brand_name",FALSE);
		$this->db->from('brands'); 
		$query = $this->db->get();
        return $query->result();
    }
	
	public function modellist(){
		$this->db->select("id, model",FALSE);
		$this->db->from('products'); 
		$this->db->order_by('model', 'asc'); 
		$query = $this->db->get();
        return $query->result();
    }
	
	public function customerlist(){
		$this->db->select("id, customer_id, customer_name, customer_type, company_name",FALSE);
		$this->db->from('customers'); 
		$query = $this->db->get();
        return $query->result();
    }
	
	public function serviceLocList(){
		$this->db->select("id, service_loc",FALSE);
		$this->db->from('service_location'); 
		$query = $this->db->get();
        return $query->result();
    }
	
	public function get_branch($id){
		$query = $this->db->get_where('customer_service_location', array('customer_id' => $id));
		return $query->result();
    }
	
	
	public function get_servicezone($id){
		$this->db->select("customer_service_location.service_zone_loc, service_location.service_loc, service_location.zone_coverage",FALSE);
    $this->db->from('customer_service_location');
    $this->db->join('service_location', 'service_location.id = customer_service_location.service_zone_loc');
	$this->db->where('customer_service_location.id', $id);
	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	public function get_probcatdetails1($id){
		$this->db->select("problem_category.prob_category As prob_category, problem_category.id As prob_catid",FALSE);
    $this->db->from('products'); 
	$this->db->join('problem_category', 'problem_category.model = products.id');	
	$this->db->where('products.id', $id);
     	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	public function get_servicecatdetails1($id){
		//echo "Hello: ".$id; exit;
		$this->db->select("products.id As modelid, products.model, service_category.service_category As service_category, service_category.id As sercat_id",FALSE);
    $this->db->from('products');
 	$this->db->join('service_charge', 'service_charge.model = products.id');
	$this->db->join('service_category', 'service_category.id = service_charge.service_cat_id'); 
	$this->db->where('service_charge.model', $id);
     	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	
	
	public function get_branchdetails($id){
		$query = $this->db->get_where('customer_service_location', array('id' => $id));
		return $query->result();
    }
	
	
	public function getsub_cat($id){
		$query = $this->db->get_where('prod_subcategory', array('prod_category_id' => $id));
		return $query->result();
		
		//$this->db->where('prod_category_id',$id);
		//return $this->db->get('prod_subcategory')->row();
    }
	
	public function get_brands($categoryid,$subcatid){
		$this->db->select("brands.brand_name, brands.id",FALSE);
		$this->db->from('brands');
		$this->db->join('products', 'products.brand = brands.id'); 
		$this->db->where('products.category',$categoryid);
		$this->db->where('products.subcategory',$subcatid);
		$query = $this->db->get();
		return $query->result();
		
		
		/* $query = $this->db->get_where('brands', array('cat_id' => $categoryid, 'subcat_id' => $subcatid));
		return $query->result(); */
		
    }
	public function get_models($categoryid,$subcatid,$brandid){
		$query = $this->db->get_where('products', array('category' => $categoryid, 'subcategory' => $subcatid, 'brand' => $brandid));
		return $query->result();
		
    }
	
	public function orderlist(){
		$where = "(order_details.warranty_date!='' or order_details.prev_main!='') and (order_details.amc_type='') and (unix_timestamp(order_details.warranty_date) > unix_timestamp(CURDATE()) or unix_timestamp(order_details.prev_main) > unix_timestamp(CURDATE()))";
		$this->db->select("order_details.id, order_details.order_id, prod_category.product_category, prod_subcategory.subcat_name, brands.brand_name, products.model, order_details.purchase_date, order_details.warranty_date, service_location.service_loc",FALSE);
    $this->db->from('order_details');
    $this->db->join('prod_category', 'prod_category.id = order_details.cat_id');
	$this->db->join('prod_subcategory', 'prod_subcategory.id = order_details.subcat_id'); 
	$this->db->join('brands', 'brands.id = order_details.brand_id'); 
	$this->db->join('products', 'products.id = order_details.model_id'); 
	$this->db->join('service_location', 'service_location.id = order_details.service_loc_id'); 
	$this->db->where($where);
	//$this->db->order_by('order_details.order_id', 'asc'); 	
     	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	
	public function orderlist1(){
		$where = "(order_details.warranty_date!='' or order_details.prev_main!='') and (order_details.amc_type='') and (unix_timestamp(order_details.warranty_date) > unix_timestamp(CURDATE()) or unix_timestamp(order_details.prev_main) > unix_timestamp(CURDATE()))";
		$this->db->select("orders.id, customers.customer_name,customers.customer_type,customer_type.type, customer_service_location.branch_name",FALSE);
    $this->db->from('orders');
	$this->db->join('order_details', 'order_details.order_id=orders.id');
    $this->db->join('customers', 'customers.id=orders.customer_id');
	$this->db->join('customer_type', 'customer_type.id=customers.customer_type');
	$this->db->join('customer_service_location', 'customer_service_location.id=orders.customer_service_loc_id');
	$this->db->where($where);
	$this->db->order_by('orders.id', 'asc'); 	
     	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	
	
	public function amclist(){
		
		$query = $this->db->query("SELECT ord.id, ord.order_id, pcat.product_category, psubcat.subcat_name, brnd.brand_name, prod.model, ord.purchase_date, ord.warranty_date, ord.prenos, ord.prenos_cnt, ord.paid, ord.amc_type, ord.prev_main, s_loc.service_loc, ord.amc_start_date, ord.amc_end_date from order_details As ord 
		inner join prod_category As pcat ON pcat.id = ord.cat_id
		inner join prod_subcategory As psubcat ON psubcat.id = ord.subcat_id
		inner join brands As brnd ON brnd.id = ord.brand_id
		inner join products As prod ON prod.id = ord.model_id
		inner join service_location As s_loc ON s_loc.id = ord.service_loc_id WHERE ord.amc_type!='' and unix_timestamp(ord.amc_end_date) > unix_timestamp(CURDATE())");
         //echo $this->db->last_query();exit;
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
		
		
    }
	
	public function amclist1(){
		$query = $this->db->query("SELECT orders.id, customers.customer_name,customers.customer_type,customer_type.type,customers.company_name, customer_service_location.branch_name from orders As orders 
		inner join order_details As order_details ON order_details.order_id=orders.id
		inner join customers As customers ON customers.id=orders.customer_id
		inner join customer_service_location As customer_service_location ON customer_service_location.id=orders.customer_service_loc_id
		inner join customer_type As customer_type ON customer_type.id=customers.customer_type
		WHERE order_details.amc_type!='' and unix_timestamp(order_details.amc_end_date) > unix_timestamp(CURDATE()) ORDER BY orders.id DESC");
   
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	public function update_amc($data,$id){ 
        $this->db->where('order_id',$id); 
		$this->db->update('order_details',$data);
    }
	
	public function expiry_closed(){
		$query = $this->db->query("SELECT ord.id,cust.customer_name,cust.company_name	,pro.product_name,pro.model, ordt.purchase_date,ordt.warranty_date,ordt.prev_main,ordt.amc_type,ordt.paid, ordt.amc_end_date,ser_loc.service_loc FROM `order_details` As ordt
						inner join orders As ord ON ord.id = ordt.order_id
						inner join customers As cust ON cust.id = ord.customer_id
						inner join products As pro ON pro.id = ordt.model_id
						inner join service_location As ser_loc ON ser_loc.id = ordt.service_loc_id
						WHERE (ordt.paid='paid') or ((unix_timestamp(ordt.warranty_date) < unix_timestamp(CURDATE()) and ordt.warranty_date!='' and ordt.paid='') or (unix_timestamp(ordt.prev_main) < unix_timestamp(CURDATE()) and ordt.prev_main!='' and ordt.paid='') or (unix_timestamp(ordt.amc_end_date) < unix_timestamp(CURDATE()) and ordt.amc_end_date!='' and ordt.paid='')) ORDER BY ord.id DESC");
		/* $this->db->from('orders');
	    $this->db->join('order_details', 'order_details.order_id=orders.id');
		$this->db->join('customers', 'customers.id=orders.customer_id');
		$this->db->join('products', 'products.id=order_details.model_id');
		$this->db->join('service_location', 'service_location.id=order_details.service_loc_id');
		$this->db->where('orders.status', 'closed');
		
		//$this->db->order_by('orders.id', 'asc'); 	
     	$query = $this->db->get();
		//echo $this->db->last_query();
//exit;
		//echo "Query:". $this->db->last_query();		
		//echo "<pre>";print_r($query->result()); */
        return $query->result();
    }
	
	public function get_productdetbyid($id){
		$this->db->select("products.id, products.category, products.subcategory, products.brand, products.model, prod_category.product_category, prod_subcategory.subcat_name, brands.brand_name",FALSE);
    $this->db->from('products');
    $this->db->join('prod_category', 'prod_category.id = products.category');
	$this->db->join('prod_subcategory', 'prod_subcategory.id = products.subcategory'); 
	$this->db->join('brands', 'brands.id = products.brand'); 
	$this->db->where('products.id', $id);
	$query = $this->db->get();

        return $query->result();
    }
	public function order_cnt(){
		$this->db->select("id",FALSE);
		$this->db->from('orders'); 
		$this->db->order_by('id', 'desc'); 
		$this->db->limit(1);	
		$query = $this->db->get();
		return $query->result();
    }
	
	
	
	public function getorderbyid($id){
		$this->db->select("orders.id, orders.order_id, orders.customer_id, orders.contact_name, orders.mobile, orders.email_id, orders.address, orders.city, orders.state, orders.pincode, orders.zone_coverage, customers.customer_name, customer_service_location.branch_name, customer_service_location.id As cslid",FALSE);
    $this->db->from('orders');
	$this->db->join('customers', 'customers.id=orders.customer_id');
	$this->db->join('customer_service_location', 'customer_service_location.id=orders.customer_service_loc_id');
    $this->db->where('orders.id', $id);
     	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	public function update_status($data,$id){ 
        $this->db->where('order_id',$id); 
		$this->db->update('order_details',$data);
    }
	/* public function update_status($data,$id){ 
        $this->db->where('id',$id); 
		$this->db->update('orders',$data);
    } */
	public function Update_order_details($data1,$where){
		/*  echo "<pre>";
	  print_r($data1);
	  echo "Where: ".$where;
	  exit; */
		$qry = $this->db->update_string('order_details', $data1, $where); 
		$this->db->query($qry);
		/* echo $this->db->last_query();
		exit; */
		//exit; 
    }
	public function getOrderDetailsbyid($id){
		$this->db->select("order_details.id, order_details.order_id, order_details.serial_no, order_details.batch_no, order_details.cat_id, order_details.subcat_id, order_details.brand_id, order_details.model_id, order_details.service_loc_id, order_details.purchase_date, order_details.paid, order_details.warranty_date, order_details.prev_main, order_details.prenos, products.model, products.id As pid, prod_category.product_category As cat_name,prod_subcategory.subcat_name As subcat_name,brands.brand_name As brand_name,service_location.service_loc As service_zone,order_details.notes,order_details.amc_type,order_details.amc_start_date,order_details.amc_end_date",FALSE);
    $this->db->from('order_details');
	$this->db->join('products', 'products.id=order_details.model_id');
	$this->db->join('prod_category', 'prod_category.id=order_details.cat_id');
	$this->db->join('prod_subcategory', 'prod_subcategory.id=order_details.subcat_id');
	$this->db->join('brands', 'brands.id=order_details.brand_id');
	$this->db->join('service_location', 'service_location.id=order_details.service_loc_id');
	$this->db->where('order_details.order_id', $id);
     	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
		
    }
	
	public function update_orders($data,$id){ 
        $this->db->where('id',$id); 
		$this->db->update('orders',$data);
    }
	
	public function delete_order_details($id){
        $this->db->where('order_id',$id);
        $this->db->delete('order_details');
    }
	
	public function delete_orders($id){
        $this->db->where('id',$id);
        $this->db->delete('orders');
    }
	
}