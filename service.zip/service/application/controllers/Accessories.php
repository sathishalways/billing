<?php 
class accessories extends CI_Controller{

    function __construct(){
     parent::__construct();
    $this->load->helper('url');
    $this->load->model('Accessories_model');

    }
    
    
    public function add_accessories(){
		
        $acc_name=$this->input->post('acc_name');
        $c=$acc_name;
		$count=count($c); 
		
			for($i=0; $i<$count; $i++) {
				if($acc_name[$i]!=""){ 
					$data1 = array('accessory' => $acc_name[$i]);
					$result=$this->Accessories_model->add_accessory($data1);
				}
				else{
					echo "<script>window.location.href='".base_url()."pages/add_accessories';alert('Please enter Accessories');</script>";
					
				}
			}
		if(isset($result)){
			echo "<script>window.location.href='".base_url()."pages/accessories_list';alert('Accessories added');</script>";
		}
    }
    
	  
    
    
    public function update_accessories(){ 
		 $id=$this->input->post('id');
		 $data=array(
            'accessory'=>$this->input->post('acc_name')
        );
		 $s = $this->Accessories_model->update_accessory($data,$id);
		
    }
	
	public function del_accessories(){ 
		 $id=$this->input->post('id');
		 $s = $this->Accessories_model->del_accessory($id);
    }
    
    
}