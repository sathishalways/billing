<?php 
class problemcategory extends CI_Controller{

    function __construct(){
     parent::__construct();
    $this->load->helper('url');
    $this->load->model('Problemcategory_model');

    }
    
    
   public function add_prob_category(){
		
        $prob_cat_name=$this->input->post('prob_cat_name');
		$model=$this->input->post('model');
		
		
		
        $c=$prob_cat_name;
		$count=count($c); 
		
		
			for($i=0; $i<$count; $i++) {
				if($prob_cat_name[$i]!=""){ 
					$data1 = array('prob_category' => $prob_cat_name[$i], 'model' => $model[$i]);
					$result=$this->Problemcategory_model->add_problem_category($data1);
				}
				/* else{
					echo "<script>window.location.href='".base_url()."pages/add_prob_cat';alert('Please enter Problem Category');</script>";
					
				} */
			}
		
		
			
		if(isset($result)){
			echo "<script>window.location.href='".base_url()."pages/prob_cat_list';alert('Problem Category added');</script>";
		}
    }
    
	
	
	  public function update_prob_cat(){ 
		 $id=$this->uri->segment(3);
		 $data['list']=$this->Problemcategory_model->getprobcatbyid($id);
		 $data['modellist']=$this->Problemcategory_model->modellist();
		 $data['user_dat'] = $this->session->userdata('login_data');
		 $this->load->view('templates/header',$data);
		 $this->load->view('edit_probcat_list',$data);
    }
    
    
    public function update_prob_category(){ 
		 $id=$this->input->post('prob_catid');
		 $data=array('prob_category'=>$this->input->post('prob_cat_name'), 'model'=>$this->input->post('model'));
		 $s = $this->Problemcategory_model->update_prob_cat($data,$id);
		 echo "<script>window.location.href='".base_url()."pages/prob_cat_list';alert('Problem Category Updated');</script>";
		
    }
	
	public function del_prob_category(){ 
		 $id=$this->input->post('id');
		 $s = $this->Problemcategory_model->del_prob_cat($id);
    }
	
	public function addrow(){ 
		 $data['count']=$this->input->post('countid');
		 $data['modellist']=$this->Problemcategory_model->modellist();
		 $this->load->view('problemaddrow',$data);
    }
	
	 public function category_validation()
	{
		$category=$this->input->post('category');
		$model=$this->input->post('model');
		
		$this->Problemcategory_model->category_validation($category,$model);
	}
    
}