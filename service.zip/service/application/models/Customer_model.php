<?php 
class Customer_model extends CI_Model{
function __construct(){
parent::__construct();
$this->load->database();
}
    public function add_customer($data){
		$this->db->insert('customers',$data);
		return $this->db->insert_id();        
    }
	
	public function add_city($data){
		$this->db->insert('city',$data);
		return true;        
    }
	
	
	 public function add_service_location($data1){
		$this->db->insert_batch('customer_service_location',$data1); 
    }
	public function add_service_location1($data1){
		$this->db->insert('customer_service_location',$data1); 
    }
	
	public function add_quick_service_location($data1){
		$this->db->insert('customer_service_location',$data1); 
    }
	 public function update_service_location($data1,$where){
		/*  echo "<pre>";
	  print_r($data1);
	  echo "Where: ".$where;
	  exit; */
		$qry = $this->db->update_string('customer_service_location', $data1, $where); 
		$this->db->query($qry);
		/* echo $this->db->last_query();
		exit; */
		//exit; 
    }
	
	
	public function customer_list(){
		$this->db->select("customers.id,customers.customer_id,customers.customer_name,customers.customer_type,customers.company_name,customers.mobile,customers.email_id,customers.city,customer_type.type",FALSE);
		$this->db->from('customers'); 
		$this->db->join('customer_type', 'customer_type.id=customers.customer_type');
		$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	
	public function check_cust($mob){
		$this->db->select("*",FALSE);
		$this->db->from('customers');
		$this->db->where('mobile', $mob);
     	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	
	public function get_zonearea($id){
		$this->db->select("service_location.id, service_location.serv_loc_code, service_location.service_loc, service_location.concharge, service_location.zone_coverage, zone_pincodes.area_name, zone_pincodes.id as area_id",FALSE);
		$this->db->from('zone_pincodes');
		$this->db->join('service_location', 'service_location.id = zone_pincodes.zone_code');
		$this->db->where('zone_pincodes.pincode', $id);
     	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	
	public function check_custbylandln($land_ln){
		$this->db->select("*",FALSE);
		$this->db->from('customers');
		$this->db->where('land_ln', $land_ln);
     	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
        return $query->result();
    }
	
	 public function add_cust_type($data){
		$this->db->insert('customer_type',$data);
		return true;
    }
	public function cust_type_list(){
		$this->db->select("id,type",FALSE);
		$this->db->from('customer_type'); 
		$this->db->order_by('type', 'asc'); 	
		$query = $this->db->get();
        return $query->result();
    }
	
	public function service_zone_list(){
		$this->db->select("id,serv_loc_code,service_loc,concharge,zone_coverage",FALSE);
		$this->db->from('service_location'); 
		$this->db->order_by('service_loc', 'asc'); 	
		$query = $this->db->get();
        return $query->result();
    }
	
	public function pincode_list(){
		$this->db->select("id,zone_code,area_name,pincode",FALSE);
		$this->db->from('zone_pincodes'); 
		$this->db->order_by('zone_code', 'asc'); 	
		$query = $this->db->get();
        return $query->result();
    }
	
	public function cust_cnt(){
		$this->db->select("id",FALSE);
		$this->db->from('customers'); 
		$this->db->order_by('id', 'desc'); 
		$this->db->limit(1);	
		$query = $this->db->get();
		return $query->result();
    }
	public function cust_service_loc_cnt(){
		$this->db->select("id",FALSE);
		$this->db->from('customer_service_location'); 
		$this->db->order_by('id', 'desc'); 
		$this->db->limit(1);	
		$query = $this->db->get();
		return $query->result();
    }
	
	public function state_list(){
		$this->db->select("id,state",FALSE);
		$this->db->from('state'); 
		$this->db->order_by('state', 'asc'); 
		//$this->db->limit(1);	
		$query = $this->db->get();
		return $query->result();
    }
	public function get_cities($id){
		$this->db->distinct();
		$this->db->select("city",FALSE);
		$this->db->from('city'); 
		$this->db->like('city', $id, 'after'); 
		//$this->db->limit(1);	
		$query = $this->db->get();
		return $query->result();
		
    }
	
	public function getcustomerbyid($id){
		//$this->db->select("customers.id As id, customers.customer_id As cust_id, customers.customer_name As cust_name, customers.customer_type As cust_type, customers.company_name	 As company_name, customers.mobile As mobile, customers.email_id As cust_email, customers.address As cust_addr, customers.address1 As cust_addr1, customers.city As city, customers.state As state, customers.pincode As pincode, customer_service_location.branch_name As branch_name, customer_service_location.landline As landline, customer_service_location.address As service_address, customer_service_location.address1 As service_address1, customer_service_location.city As service_city, customer_service_location.state As service_state, customer_service_location.pincode As service_pincode, customer_service_location.contact_name As contact_name, customer_service_location.designation As designation, customer_service_location.mobile As service_mobile, customer_service_location.email_id As service_email",FALSE);
    //$this->db->from('customers');
    //$this->db->join('customer_service_location', 'customers.id=customer_service_location.customer_id');
	//$this->db->where('customers.id', $id);
     //	$query = $this->db->get();
		//echo "<pre>";print_r($query->result());exit;
       // return $query->result();
		
		$query=$this->db->get_where('customers',array('id'=>$id));
        return $query->result();
    }
	
	
	public function get_states($id){
		$query=$this->db->get_where('state',array('id'=>$id));
        return $query->result();
	}
	
	public function getcustomertypebyid($id){
		$query=$this->db->get_where('customer_type',array('id'=>$id));
        return $query->result();
	}
	
	
	
	
	public function getcustservicelocationbyid($id){
		$query1=$this->db->get_where('customer_service_location',array('customer_id'=>$id));
        return $query1->result();
    }
	
	public function update_customer($data,$id){ 
        $this->db->where('id',$id); 
		$this->db->update('customers',$data);
    }
	
	public function update_customer_service_loc($data,$id,$ser_loc_id){ //echo $ids;echo "<pre>";print_r($data);exit;
        $this->db->where('id',$ser_loc_id); 
		$this->db->where('customer_id',$id);
		$this->db->update('customer_service_location',$data);
    }
	public function update_customer_type($data,$id){ 
        $this->db->where('id',$id); 
		$this->db->update('customer_type',$data);
    }
	
	public function delete_customer_service_loc($id){
       
    $this->db->where('customer_id',$id);
        $this->db->delete('customer_service_location');
    }
	
	public function del_customers($id){
        $this->db->where('id',$id);
        $this->db->delete('customers');
    }
	public function del_customer_type($id){
        $this->db->where('id',$id);
        $this->db->delete('customer_type');
    }
	
	public function custtype_validation($product_id)
	{
		$query = $this->db->get_where('customer_type', array('type' => $product_id));
        return $numrow = $query->num_rows();
	}
	
}