<?php 
class service extends CI_Controller{

    function __construct(){
     parent::__construct();
    $this->load->helper('url');
    $this->load->model('Service_model');

    }
    
    public function get_zone_list(){
		$id=$this->input->post('keyword');//echo $id; exit;
		$data['zone_list']=$this->Service_model->get_zons($id);
		$this->load->view('zone_list',$data);
		
    }
	
	public function view_claim(){
		$this->load->helper('pdf_helper');
		$id=$this->uri->segment(3);
		$data1['warran_mode'] = $this->uri->segment(4);
		$view_claim=$this->Service_model->view_claim($id);
		
		foreach($view_claim as $claimKey){
			$data1['quote_req_id'] = $claimKey->quote_req_id;
			$data1['desc_failure'] = $claimKey->desc_failure;
			$data1['why_failure'] = $claimKey->why_failure;
			$data1['correct_action'] = $claimKey->correct_action;
			$data1['spare_qty'] = $claimKey->spare_qty;
			$data1['request_id'] = $claimKey->request_id;
			$data1['request_date'] = $claimKey->request_date;
			
			$data1['serial_no'] = $claimKey->serial_no;
			$data1['model'] = $claimKey->model;
			$data1['company_name'] = $claimKey->company_name;
			
			$data1['address'] = $claimKey->address;
			$data1['address1'] = $claimKey->address1;
			
			$data1['city'] = $claimKey->city;
			$data1['state'] = $claimKey->state;
			$data1['pincode'] = $claimKey->pincode;
			$data1['spare_details'] = $claimKey->spare_details;
			$data1['purchase_date'] = $claimKey->purchase_date;
		}
		
		
		
		//$data1['user_dat'] = $this->session->userdata('login_data');
		//$this->load->view('templates/header',$data1);
		$this->load->view('view_claim',$data1);
    }
	
	public function topdf($id=NULL,$option=NULL)
	{
		//echo "REquest Id: ".$id;exit;
		//$this->load->model('invoiceModel');
		//$this->load->library('Numbertowords');
		//$this->load->model('settings/Mdl_Settings');
		$idd=$this->uri->segment(3);
		$data1['warran_mode'] = $this->uri->segment(4);
		$data1['view_claim']=$this->Service_model->view_claim($idd);
		
		
		
		if(!$id)
		{
			echo "No More Access"; exit;	
		}
		else
		{
                                
				//$ht=$this->view($id,"without_template","module");
               $ht= $this->load->view('view_claim',$data1);
				 
				$html='<html> <head> </head> <body> <style type="text/css">.cncl-bg{display:none} </style>'.$ht.' <link href="'.base_url().'assets/css/invoice_pdf.css" rel="stylesheet" type="text/css" /></body></html>';
			///	echo $html; exit;
				$paper='A4';
        			$this->load->library('pdf'); 
                                 //include('../mpdf.php');
                                
				$base=str_replace("system/","",BASEPATH);   
				//$invoiceinfo = $this->invoiceModel->getInvoiceinfoById($id);
			
			//	if($invoiceinfo->status=='C')
				//$mark=$base."images/canceled.png";
				//else
				$mark=NULL;
                             
				//if($option=="")
                               $this->pdf->downloadPdf($html,NULL,$mark);
                                 
                               
                                			                        
		}
		
	}
	
    public function add_service_req(){ //echo "<pre>";print_r($_POST);exit;
		
		error_reporting(0);
		ini_set('max_execution_time', 900);
		$req=$this->input->post('req_id');
		$check_req=$this->Service_model->check_req($req);
		
		$serl_no = $this->input->post('serial_no');
		/* echo "<pre>";
		print_r($serl_no);
		exit; */
		
		$service_typ = $this->input->post('service_type');
		
		
		if(empty($check_req)){
			
			if($service_typ=='soft_up'){
				
				if(count($serl_no) <= '1'){
				
				$srl_nos = $serl_no[0];
				$srl_nos_arr = explode(',', $srl_nos);
				$real_srno = $srl_nos_arr[0];
				$warrant_date = $srl_nos_arr[1];
				$mach_status = $srl_nos_arr[2];
				$amc_typ = $srl_nos_arr[3];
				$btch_no = $srl_nos_arr[4];
				
				$model_ids = $srl_nos_arr[5];
				$cat_ids = $srl_nos_arr[6];
				$subcat_ids = $srl_nos_arr[7];
				$brand_ids = $srl_nos_arr[8];
				
				
				$data['request_id']=$this->input->post('req_id');
				$data['cust_name']=$this->input->post('customer_id');
				$data['br_name']=$this->input->post('br_name');
				
				$data['mobile']=$this->input->post('mobile');
				$data['email_id']=$this->input->post('email_id');
				$data['address']=$this->input->post('address');
				$data['address1']=$this->input->post('address1');
				$data['request_date']=$this->input->post('datepicker');
				$data['status']=$this->input->post('status');
				
				date_default_timezone_set('Asia/Calcutta');
				$data['created_on'] = date("Y-m-d H:i:s");
				$data['updated_on'] = date("Y-m-d H:i:s");
				
				$data111['user_dat'] = $this->session->userdata('login_data');
				$data['user_id'] = $data111['user_dat'][0]->id;
				
				$req_autoid=$this->input->post('req_id');
				
				$customer_mobile=$this->input->post('mobile');
				
				$result=$this->Service_model->add_services($data);
				$res = sprintf("%05d", $result);
				
				if($result){
					
					if(isset($customer_mobile) && $customer_mobile!=""){
						
						$re_date = $this->input->post('datepicker');
						$curr_date = date("Y-m-d");
						
						$sms= "Your service request ID ".$req." created. Pls contact 9841443300 for Quote/status/delivery of your machine. <br>SRScales<br> 64606666";
						$messages	= strip_tags($sms);
						$messages = str_replace(' ','%20',$messages);
					
						$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=srscales&pass=9841038810&sender=SRSCAL&phone=$customer_mobile&text=$messages&priority=sdnd&stype=normal");
						
					}
					
					
				$data1['request_id'] = $res;
				$data1['serial_no'] = $real_srno;
			   
				$data1['cat_id']=$cat_ids;
				$data1['subcat_id']=$subcat_ids;
				$data1['brand_id']=$brand_ids;
				$data1['model_id']=$model_ids;
				
				if($warrant_date!=""){
					$data1['warranty_date'] = $warrant_date;
				}else{
					$data1['warranty_date'] = "";
				}
				
				if($mach_status!=""){
					$data1['machine_status'] = $mach_status;
				}else{
					$data1['machine_status'] = "";
				}
				
				
				$app_time = $this->input->post('app_time');
				if($app_time!=""){
					$data1['app_time'] = $this->input->post('app_time');
				}else{
					$data1['app_time'] = '';
				}
				
				$addl_engg_name = $this->input->post('addl_engg_name');
				if($addl_engg_name!=""){
					$data1['addl_engg_name'] = $this->input->post('addl_engg_name');
				}else{
					$data1['addl_engg_name'] = '';
				}
				
				$data1['service_type']=$this->input->post('service_type');
				//$data1['service_cat']=$this->input->post('service_cat');
				$ser_det = $this->input->post('service_cat');
				$ser = explode("-",$ser_det);
				$data1['service_cat'] = $ser['0'];
				
				$data1['zone']=$this->input->post('locid');
				$data1['service_loc_coverage']=$this->input->post('service_loc_coverage');
				
				$data1['problem']=$this->input->post('probi');
				
				if (is_array($data1['problem'])){
							$data1['problem']= implode(",",$data1['problem']);
						}else{
							$data1['problem']="";
						}
				
				//$data1['problem']=$this->input->post('prob');
				//$data1['assign_to']=$this->input->post('assign_to');
				$data1['service_priority']=$this->input->post('service_priority');
				$data1['blank_app']=$this->input->post('blank_app');
				
				if($btch_no!=""){
					$data1['batch_no']=$btch_no;
				}else{
					$data1['batch_no']="";
				}
				
				
				$emm_id=$this->input->post('assign_to');
				//$emp_det = $this->input->post('assign_to');
				//$emp = explode(",",$emp_det);
				//$data1['assign_to'] = $emp['0']; 
				
				if(isset($emm_id) && $emm_id!=""){
					 $ass_to = $this->input->post('assign_to');
					 $em_id =  explode("-", $ass_to);
				 
					 $data1['assign_to'] = $em_id['0'];
				
					 $emp_id = $em_id['0']; 
					 $sms_mob=$em_id['1'];
				}
				//echo "Hsssssi: ".$em_id['0']; exit;
				
				if($em_id['1']!="" && isset($em_id['1'])){ 
					$sms_mobs=$em_id['1'];
					$cust_name = $this->input->post('customer_name');
					//$modell = $this->input->post('model');
					$model_name = $this->Service_model->get_modelById($model_ids);
					$modell = $model_name[0]->model;
					
					
					$service_types = $this->input->post('service_type');
					
					$sms= "ID:".$req;
					$sms.= " Name:".$cust_name;
					if ($this->input->post('address')!=""){
						$sms.= ", ".$this->input->post('address').' '.$this->input->post('address1');
					}
					if ($this->input->post('mobile')!=""){
						$sms.= ",".$this->input->post('mobile');
					}
					//$sms.= " Brand: ".$brand_name; 
					$sms.= ",Model:".$modell;
					if($service_types=='AMC'){
						$sms.= ",Service Type: AMC";
					}
					if($service_types=='Out Of Warranty'){
						$sms.= ",Service Type: Out Of Warranty";
					}
					if($service_types=='Breakdown'){
						$sms.= ",Service Type: Breakdown";
					}
					if($service_types=='Preventive'){
						$sms.= ",Service Type: Preventive";
					}
					if($service_types=='Demo'){
						$sms.= ",Service Type: Demo";
					}
					if($service_types=='Delivery'){
						$sms.= ",Service Type: Delivery";
					}
					if($service_types=='Installation'){
						$sms.= ",Service Type: Installation";
					}
					if($service_types=='soft_up'){
						$sms.= ",Service Type: Software Upgradation";
					}
					if($service_types=='Reverification'){
						$sms.= ",Service Type: Reverification";
					}
					
					
					
					if ($this->input->post('probi')!=""){
						
						foreach($this->input->post('probi') as $val_pro){
							$sms_problemlist=$this->Service_model->sms_problemlist($val_pro);
							$sms.=",".$sms_problemlist[0]->prob_category;
						}
						
					}
					
					if ($this->input->post('blank_app')!=""){
						$sms.= ",Blanket Appr: ".$this->input->post('blank_app');
					}
					
					$messages	= strip_tags($sms);
					$messages = str_replace(' ','%20',$messages);
					
					//$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=arihantmarketing&pass=123&sender=BHASH&phone=$sms_mobs&text=$messages&priority=dnd&stype=normal");
					
					$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=srscales&pass=9841038810&sender=SRSCAL&phone=$sms_mobs&text=$messages&priority=sdnd&stype=normal");
				}
				
				
				
				$data1['received']=$this->input->post('received');
				if (is_array($data1['received'])){
							$data1['received']= implode(",",$data1['received']);
						}else{
							$data1['received']="";
						}
						
				
				$data1['notes']=$this->input->post('notes');
				//$countids=$this->input->post('countids');
				
				
				
				$result1=$this->Service_model->add_service_details($data1);
				}
				
				if($result){
				    echo "<script>alert('Service Request Added. Your Request ID is: '+'".$req_autoid."');window.location.href='".base_url()."pages/service_req_list';window.open('".base_url()."service/print_service/".$res."')</script>";
				}
			}else{ 
				
				$l = 1;
				for($k=0;$k<count($serl_no);$k++){
					
					
					$srl_nos = $serl_no[$k];
				$srl_nos_arr = explode(',', $srl_nos);
				$real_srno = $srl_nos_arr[0];
				$warrant_date = $srl_nos_arr[1];
				$mach_status = $srl_nos_arr[2];
				$amc_typ = $srl_nos_arr[3];
				$btch_no = $srl_nos_arr[4];
				
				$model_ids = $srl_nos_arr[5];
				$cat_ids = $srl_nos_arr[6];
				$subcat_ids = $srl_nos_arr[7];
				$brand_ids = $srl_nos_arr[8];
				
				
				
				$reqiddd = $this->input->post('req_id').'-'.$l;
				$data['request_id']=$this->input->post('req_id').'-'.$l;
				$data['cust_name']=$this->input->post('customer_id');
				$data['br_name']=$this->input->post('br_name');
				
				$data['mobile']=$this->input->post('mobile');
				$data['email_id']=$this->input->post('email_id');
				$data['address']=$this->input->post('address');
				$data['address1']=$this->input->post('address1');
				$data['request_date']=$this->input->post('datepicker');
				$data['status']=$this->input->post('status');
				
				date_default_timezone_set('Asia/Calcutta');
				$data['created_on'] = date("Y-m-d H:i:s");
				$data['updated_on'] = date("Y-m-d H:i:s");
				
				$data111['user_dat'] = $this->session->userdata('login_data');
				$data['user_id'] = $data111['user_dat'][0]->id;
				
				$req_autoid=$this->input->post('req_id');
				
				$customer_mobile=$this->input->post('mobile');
				
				$result=$this->Service_model->add_services($data);
				$res = sprintf("%05d", $result);
				
				if($result){
					
					if(isset($customer_mobile) && $customer_mobile!=""){
						$re_date = $this->input->post('datepicker');
						$curr_date = date("Y-m-d");
						$sms= "Your service request ID ".$reqiddd." created. Pls contact 9710411488 for Quote/status/delivery of your machine. <br>SRScales<br> 64606666";
						$messages	= strip_tags($sms);
						$messages = str_replace(' ','%20',$messages);
					
						$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=srscales&pass=9841038810&sender=SRSCAL&phone=$customer_mobile&text=$messages&priority=sdnd&stype=normal");
						
					}
					
					
				$data1['request_id'] = $res;
				$data1['serial_no'] = $real_srno;
			   
				$data1['cat_id']=$cat_ids;
				$data1['subcat_id']=$subcat_ids;
				$data1['brand_id']=$brand_ids;
				$data1['model_id']=$model_ids;
				
				if($warrant_date!=""){
					$data1['warranty_date'] = $warrant_date;
				}else{
					$data1['warranty_date'] = "";
				}
				
				if($mach_status!=""){
					$data1['machine_status'] = $mach_status;
				}else{
					$data1['machine_status'] = "";
				}
				
				
				$app_time = $this->input->post('app_time');
				if($app_time!=""){
					$data1['app_time'] = $this->input->post('app_time');
				}else{
					$data1['app_time'] = '';
				}
				
				$addl_engg_name = $this->input->post('addl_engg_name');
				if($addl_engg_name!=""){
					$data1['addl_engg_name'] = $this->input->post('addl_engg_name');
				}else{
					$data1['addl_engg_name'] = '';
				}
				
				$data1['service_type']=$this->input->post('service_type');
				//$data1['service_cat']=$this->input->post('service_cat');
				$ser_det = $this->input->post('service_cat');
				$ser = explode("-",$ser_det);
				$data1['service_cat'] = $ser['0'];
				
				$data1['zone']=$this->input->post('locid');
				$data1['service_loc_coverage']=$this->input->post('service_loc_coverage');
				
				$data1['problem']=$this->input->post('probi');
				
				if (is_array($data1['problem'])){
							$data1['problem']= implode(",",$data1['problem']);
						}else{
							$data1['problem']="";
						}
				
				//$data1['problem']=$this->input->post('prob');
				//$data1['assign_to']=$this->input->post('assign_to');
				$data1['service_priority']=$this->input->post('service_priority');
				$data1['blank_app']=$this->input->post('blank_app');
				
				if($btch_no!=""){
					$data1['batch_no']=$btch_no;
				}else{
					$data1['batch_no']="";
				}
				
				$emm_id=$this->input->post('assign_to');
				//$emp_det = $this->input->post('assign_to');
				//$emp = explode(",",$emp_det);
				//$data1['assign_to'] = $emp['0']; 
				
				if(isset($emm_id) && $emm_id!=""){
					 $ass_to = $this->input->post('assign_to');
					 $em_id =  explode("-", $ass_to);
				 
					 $data1['assign_to'] = $em_id['0'];
				
					 $emp_id = $em_id['0']; 
					 $sms_mob=$em_id['1'];
				}
				//echo "Hsssssi: ".$em_id['0']; exit;
			
				
				if($em_id['1']!="" && isset($em_id['1'])){ 
					$sms_mobs=$em_id['1'];
					$cust_name = $this->input->post('customer_name');
					//$modell = $this->input->post('model');
					$model_name = $this->Service_model->get_modelById($model_ids);
					$modell = $model_name[0]->model;
					
					//$brand_name = $this->input->post('brand_name');
					$service_types = $this->input->post('service_type');
					
					$sms= "ID:".$reqiddd;
					$sms.= " Name:".$cust_name;
					if ($this->input->post('address')!=""){
						$sms.= ", ".$this->input->post('address').' '.$this->input->post('address1');
					}
					if ($this->input->post('mobile')!=""){
						$sms.= ",".$this->input->post('mobile');
					}
					//$sms.= " Brand: ".$brand_name; 
					$sms.= ",Model:".$modell;
					if($service_types=='AMC'){
						$sms.= ",Service Type: AMC";
					}
					if($service_types=='Out Of Warranty'){
						$sms.= ",Service Type: Out Of Warranty";
					}
					if($service_types=='Breakdown'){
						$sms.= ",Service Type: Breakdown";
					}
					if($service_types=='Preventive'){
						$sms.= ",Service Type: Preventive";
					}
					if($service_types=='Demo'){
						$sms.= ",Service Type: Demo";
					}
					if($service_types=='Delivery'){
						$sms.= ",Service Type: Delivery";
					}
					if($service_types=='Installation'){
						$sms.= ",Service Type: Installation";
					}
					if($service_types=='soft_up'){
						$sms.= ",Service Type: Software Upgradation";
					}
					if($service_types=='Reverification'){
						$sms.= ",Service Type: Reverification";
					}
					
					
					
					if ($this->input->post('probi')!=""){
						
						foreach($this->input->post('probi') as $val_pro){
							$sms_problemlist=$this->Service_model->sms_problemlist($val_pro);
							$sms.=",".$sms_problemlist[0]->prob_category;
						}
						
					}
					
					if ($this->input->post('blank_app')!=""){
						$sms.= ",Blanket Appr: ".$this->input->post('blank_app');
					}
					
					$messages	= strip_tags($sms);
					$messages = str_replace(' ','%20',$messages);
					
					//$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=arihantmarketing&pass=123&sender=BHASH&phone=$sms_mobs&text=$messages&priority=dnd&stype=normal");
					
					$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=srscales&pass=9841038810&sender=SRSCAL&phone=$sms_mobs&text=$messages&priority=sdnd&stype=normal");
				}
				
				
				
				$data1['received']=$this->input->post('received');
				if (is_array($data1['received'])){
							$data1['received']= implode(",",$data1['received']);
						}else{
							$data1['received']="";
						}
						
				
				$data1['notes']=$this->input->post('notes');
				//$countids=$this->input->post('countids');
				
				
				
				$result1=$this->Service_model->add_service_details($data1);
				}
				
				if($result){
				    echo "<script>alert('Service Request Added. Your Request ID is: '+'".$req_autoid."');window.location.href='".base_url()."pages/service_req_list';window.open('".base_url()."service/print_service/".$res."')</script>";
				}
					
				$l++; }
			}
				
				
			}else{
				if(count($serl_no) <= '1'){
				
				$srl_nos = $serl_no[0];
				$srl_nos_arr = explode(',', $srl_nos);
				$real_srno = $srl_nos_arr[0];
				$warrant_date = $srl_nos_arr[1];
				$mach_status = $srl_nos_arr[2];
				$amc_typ = $srl_nos_arr[3];
				$btch_no = $srl_nos_arr[4];
				
				$data['request_id']=$this->input->post('req_id');
				$data['cust_name']=$this->input->post('customer_id');
				$data['br_name']=$this->input->post('br_name');
				
				$data['mobile']=$this->input->post('mobile');
				$data['email_id']=$this->input->post('email_id');
				$data['address']=$this->input->post('address');
				$data['address1']=$this->input->post('address1');
				$data['request_date']=$this->input->post('datepicker');
				$data['status']=$this->input->post('status');
				
				date_default_timezone_set('Asia/Calcutta');
				$data['created_on'] = date("Y-m-d H:i:s");
				$data['updated_on'] = date("Y-m-d H:i:s");
				
				$data111['user_dat'] = $this->session->userdata('login_data');
				$data['user_id'] = $data111['user_dat'][0]->id;
				
				$req_autoid=$this->input->post('req_id');
				
				$customer_mobile=$this->input->post('mobile');
				
				$result=$this->Service_model->add_services($data);
				$res = sprintf("%05d", $result);
				
				if($result){
					
					if(isset($customer_mobile) && $customer_mobile!=""){
						$re_date = $this->input->post('datepicker');
						$curr_date = date("Y-m-d");
						
						$sms= "Your service request ID ".$req." created. Pls contact 9710411488 for Quote/status/delivery of your machine. <br>SRScales<br> 64606666";
						$messages	= strip_tags($sms);
						$messages = str_replace(' ','%20',$messages);
					
						$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=srscales&pass=9841038810&sender=SRSCAL&phone=$customer_mobile&text=$messages&priority=sdnd&stype=normal");
						
					}
					
					
				$data1['request_id'] = $res;
				$data1['serial_no'] = $real_srno;
			   
				$data1['cat_id']=$this->input->post('categoryid');
				$data1['subcat_id']=$this->input->post('subcategoryid');
				$data1['brand_id']=$this->input->post('brandid');
				$data1['model_id']=$this->input->post('modelid');
				
				if($warrant_date!=""){
					$data1['warranty_date'] = $warrant_date;
				}else{
					$data1['warranty_date'] = "";
				}
				
				if($mach_status!=""){
					$data1['machine_status'] = $mach_status;
				}else{
					$data1['machine_status'] = "";
				}
				
				$app_time = $this->input->post('app_time');
				if($app_time!=""){
					$data1['app_time'] = $this->input->post('app_time');
				}else{
					$data1['app_time'] = '';
				}
				
				$addl_engg_name = $this->input->post('addl_engg_name');
				if($addl_engg_name!=""){
					$data1['addl_engg_name'] = $this->input->post('addl_engg_name');
				}else{
					$data1['addl_engg_name'] = '';
				}
				
				$data1['service_type']=$this->input->post('service_type');
				//$data1['service_cat']=$this->input->post('service_cat');
				$ser_det = $this->input->post('service_cat');
				$ser = explode("-",$ser_det);
				$data1['service_cat'] = $ser['0'];
				
				$data1['zone']=$this->input->post('locid');
				$data1['service_loc_coverage']=$this->input->post('service_loc_coverage');
				
				$data1['problem']=$this->input->post('probi');
				
				if (is_array($data1['problem'])){
							$data1['problem']= implode(",",$data1['problem']);
						}else{
							$data1['problem']="";
						}
				
				//$data1['problem']=$this->input->post('prob');
				//$data1['assign_to']=$this->input->post('assign_to');
				$data1['service_priority']=$this->input->post('service_priority');
				$data1['blank_app']=$this->input->post('blank_app');
				
				if($btch_no!=""){
					$data1['batch_no']=$btch_no;
				}else{
					$data1['batch_no']="";
				}
				
				
				$emm_id=$this->input->post('assign_to');
				//$emp_det = $this->input->post('assign_to');
				//$emp = explode(",",$emp_det);
				//$data1['assign_to'] = $emp['0']; 
				
				if(isset($emm_id) && $emm_id!=""){
					 $ass_to = $this->input->post('assign_to');
					 $em_id =  explode("-", $ass_to);
				 
					 $data1['assign_to'] = $em_id['0'];
				
					 $emp_id = $em_id['0']; 
					 $sms_mob=$em_id['1'];
				}
				//echo "Hsssssi: ".$em_id['0']; exit;
				
				if($em_id['1']!="" && isset($em_id['1'])){ 
					$sms_mobs=$em_id['1'];
					$cust_name = $this->input->post('customer_name');
					$modell = $this->input->post('model');
					//$model_name = $this->Service_model->get_modelById($model_ids);
					//$modell = $model_name[0]->model;
					
					//$brand_name = $this->input->post('brand_name');
					$service_types = $this->input->post('service_type');
					
					$sms= "ID:".$req;
					$sms.= " Name:".$cust_name;
					if ($this->input->post('address')!=""){
						$sms.= ", ".$this->input->post('address').' '.$this->input->post('address1');
					}
					if ($this->input->post('mobile')!=""){
						$sms.= ",".$this->input->post('mobile');
					}
					//$sms.= " Brand: ".$brand_name; 
					$sms.= ",Model:".$modell;
					
					if($service_types=='AMC'){
						$sms.= ",Service Type: AMC";
					}
					if($service_types=='Out Of Warranty'){
						$sms.= ",Service Type: Out Of Warranty";
					}
					if($service_types=='Breakdown'){
						$sms.= ",Service Type: Breakdown";
					}
					if($service_types=='Preventive'){
						$sms.= ",Service Type: Preventive";
					}
					if($service_types=='Demo'){
						$sms.= ",Service Type: Demo";
					}
					if($service_types=='Delivery'){
						$sms.= ",Service Type: Delivery";
					}
					if($service_types=='Installation'){
						$sms.= ",Service Type: Installation";
					}
					if($service_types=='soft_up'){
						$sms.= ",Service Type: Software Upgradation";
					}
					if($service_types=='Reverification'){
						$sms.= ",Service Type: Reverification";
					}
					
					
					
					if ($this->input->post('probi')!=""){
						
						foreach($this->input->post('probi') as $val_pro){
							$sms_problemlist=$this->Service_model->sms_problemlist($val_pro);
							$sms.=",".$sms_problemlist[0]->prob_category;
						}
						
					}
					
					if ($this->input->post('blank_app')!=""){
						$sms.= ",Blanket Appr: ".$this->input->post('blank_app');
					}
					
					$messages	= strip_tags($sms);
					$messages = str_replace(' ','%20',$messages);
					
					//$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=arihantmarketing&pass=123&sender=BHASH&phone=$sms_mobs&text=$messages&priority=dnd&stype=normal");
					
					$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=srscales&pass=9841038810&sender=SRSCAL&phone=$sms_mobs&text=$messages&priority=sdnd&stype=normal");
				}
				
				
				
				$data1['received']=$this->input->post('received');
				if (is_array($data1['received'])){
							$data1['received']= implode(",",$data1['received']);
						}else{
							$data1['received']="";
						}
						
				
				$data1['notes']=$this->input->post('notes');
				//$countids=$this->input->post('countids');
				
				
				
				$result1=$this->Service_model->add_service_details($data1);
				}
				
				if($result){
				 	  echo "<script>alert('Service Request Added. Your Request ID is: '+'".$req_autoid."');window.location.href='".base_url()."pages/service_req_list';window.open('".base_url()."service/print_service/".$res."')</script>";
				}
			}else{ 
				
				$l = 1;
				for($k=0;$k<count($serl_no);$k++){
					
					
					$srl_nos = $serl_no[$k];
				$srl_nos_arr = explode(',', $srl_nos);
				$real_srno = $srl_nos_arr[0];
				$warrant_date = $srl_nos_arr[1];
				$mach_status = $srl_nos_arr[2];
				$amc_typ = $srl_nos_arr[3];
				$btch_no = $srl_nos_arr[4];
				
				$reqiddd = $this->input->post('req_id').'-'.$l;
				$data['request_id']=$this->input->post('req_id').'-'.$l;
				$data['cust_name']=$this->input->post('customer_id');
				$data['br_name']=$this->input->post('br_name');
				
				$data['mobile']=$this->input->post('mobile');
				$data['email_id']=$this->input->post('email_id');
				$data['address']=$this->input->post('address');
				$data['address1']=$this->input->post('address1');
				$data['request_date']=$this->input->post('datepicker');
				$data['status']=$this->input->post('status');
				
				date_default_timezone_set('Asia/Calcutta');
				$data['created_on'] = date("Y-m-d H:i:s");
				$data['updated_on'] = date("Y-m-d H:i:s");
				
				$data111['user_dat'] = $this->session->userdata('login_data');
				$data['user_id'] = $data111['user_dat'][0]->id;
				
				$req_autoid=$this->input->post('req_id');
				
				$customer_mobile=$this->input->post('mobile');
				
				$result=$this->Service_model->add_services($data);
				$res = sprintf("%05d", $result);
				
				if($result){
					
					if(isset($customer_mobile) && $customer_mobile!=""){
						$re_date = $this->input->post('datepicker');
						$curr_date = date("Y-m-d");
						
						$sms= "Your service request ID ".$reqiddd." created. Pls contact 9710411488 for Quote/status/delivery of your machine. <br>SRScales<br> 64606666";
						$messages	= strip_tags($sms);
						$messages = str_replace(' ','%20',$messages);
					
						$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=srscales&pass=9841038810&sender=SRSCAL&phone=$customer_mobile&text=$messages&priority=sdnd&stype=normal");
						
					}
					
					
				$data1['request_id'] = $res;
				$data1['serial_no'] = $real_srno;
			   
				$data1['cat_id']=$this->input->post('categoryid');
				$data1['subcat_id']=$this->input->post('subcategoryid');
				$data1['brand_id']=$this->input->post('brandid');
				$data1['model_id']=$this->input->post('modelid');
				
				if($warrant_date!=""){
					$data1['warranty_date'] = $warrant_date;
				}else{
					$data1['warranty_date'] = "";
				}
				
				if($mach_status!=""){
					$data1['machine_status'] = $mach_status;
				}else{
					$data1['machine_status'] = "";
				}
				
				
				$app_time = $this->input->post('app_time');
				if($app_time!=""){
					$data1['app_time'] = $this->input->post('app_time');
				}else{
					$data1['app_time'] = '';
				}
				
				$addl_engg_name = $this->input->post('addl_engg_name');
				if($addl_engg_name!=""){
					$data1['addl_engg_name'] = $this->input->post('addl_engg_name');
				}else{
					$data1['addl_engg_name'] = '';
				}
				
				$data1['service_type']=$this->input->post('service_type');
				//$data1['service_cat']=$this->input->post('service_cat');
				$ser_det = $this->input->post('service_cat');
				$ser = explode("-",$ser_det);
				$data1['service_cat'] = $ser['0'];
				
				$data1['zone']=$this->input->post('locid');
				$data1['service_loc_coverage']=$this->input->post('service_loc_coverage');
				
				$data1['problem']=$this->input->post('probi');
				
				if (is_array($data1['problem'])){
							$data1['problem']= implode(",",$data1['problem']);
						}else{
							$data1['problem']="";
						}
				
				//$data1['problem']=$this->input->post('prob');
				//$data1['assign_to']=$this->input->post('assign_to');
				$data1['service_priority']=$this->input->post('service_priority');
				$data1['blank_app']=$this->input->post('blank_app');
				
				if($btch_no!=""){
					$data1['batch_no']=$btch_no;
				}else{
					$data1['batch_no']="";
				}
				
				$emm_id=$this->input->post('assign_to');
				//$emp_det = $this->input->post('assign_to');
				//$emp = explode(",",$emp_det);
				//$data1['assign_to'] = $emp['0']; 
				
				if(isset($emm_id) && $emm_id!=""){
					 $ass_to = $this->input->post('assign_to');
					 $em_id =  explode("-", $ass_to);
				 
					 $data1['assign_to'] = $em_id['0'];
				
					 $emp_id = $em_id['0']; 
					 $sms_mob=$em_id['1'];
				}
				//echo "Hsssssi: ".$em_id['0']; exit;
				
				if($em_id['1']!="" && isset($em_id['1'])){ 
					$sms_mobs=$em_id['1'];
					$cust_name = $this->input->post('customer_name');
					$modell = $this->input->post('model');
					//$model_name = $this->Service_model->get_modelById($model_ids);
					//$modell = $model_name[0]->model;
					
					//$brand_name = $this->input->post('brand_name');
					$service_types = $this->input->post('service_type');
					
					$sms= "ID:".$reqiddd;
					$sms.= " Name:".$cust_name;
					if ($this->input->post('address')!=""){
						$sms.= ", ".$this->input->post('address').' '.$this->input->post('address1');
					}
					if ($this->input->post('mobile')!=""){
						$sms.= ",".$this->input->post('mobile');
					}
					//$sms.= " Brand: ".$brand_name; 
					$sms.= ",Model:".$modell;
					
					if($service_types=='AMC'){
						$sms.= ",Service Type: AMC";
					}
					if($service_types=='Out Of Warranty'){
						$sms.= ",Service Type: Out Of Warranty";
					}
					if($service_types=='Breakdown'){
						$sms.= ",Service Type: Breakdown";
					}
					if($service_types=='Preventive'){
						$sms.= ",Service Type: Preventive";
					}
					if($service_types=='Demo'){
						$sms.= ",Service Type: Demo";
					}
					if($service_types=='Delivery'){
						$sms.= ",Service Type: Delivery";
					}
					if($service_types=='Installation'){
						$sms.= ",Service Type: Installation";
					}
					if($service_types=='soft_up'){
						$sms.= ",Service Type: Software Upgradation";
					}
					if($service_types=='Reverification'){
						$sms.= ",Service Type: Reverification";
					}
					
					
					
					if ($this->input->post('probi')!=""){
						
						foreach($this->input->post('probi') as $val_pro){
							$sms_problemlist=$this->Service_model->sms_problemlist($val_pro);
							$sms.=",".$sms_problemlist[0]->prob_category;
						}
						
					}
					
					if ($this->input->post('blank_app')!=""){
						$sms.= ",Blanket Appr: ".$this->input->post('blank_app');
					}
					
					$messages	= strip_tags($sms);
					$messages = str_replace(' ','%20',$messages);
					
					//$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=arihantmarketing&pass=123&sender=BHASH&phone=$sms_mobs&text=$messages&priority=dnd&stype=normal");
					
					$msg = file_get_contents("http://bhashsms.com/api/sendmsg.php?user=srscales&pass=9841038810&sender=SRSCAL&phone=$sms_mobs&text=$messages&priority=sdnd&stype=normal");
				}
				
				
				
				$data1['received']=$this->input->post('received');
				if (is_array($data1['received'])){
							$data1['received']= implode(",",$data1['received']);
						}else{
							$data1['received']="";
						}
						
				
				$data1['notes']=$this->input->post('notes');
				//$countids=$this->input->post('countids');
				
				
				
				$result1=$this->Service_model->add_service_details($data1);
				}
				
				if($result){
				    echo "<script>alert('Service Request Added. Your Request ID is: '+'".$req_autoid."');window.location.href='".base_url()."pages/service_req_list';window.open('".base_url()."service/print_service/".$res."')</script>";
				}
					
					
				$l++; }
			}
			}
			
			
			
        
	 
		}else{
			echo "<script>alert('Service Request ID already exists');window.location.href='".base_url()."pages/add_service_req';</script>";
		}
    
    }
	public function print_service(){ 
		$id=$this->uri->segment(3);
		$data['url_id'] = $this->uri->segment(3);
		
		$data['list']=$this->Service_model->getservicereqbyid($id);
		//$data['list1']=$this->Service_model->getservicereqDetailsbyid($id);
		
		$data['list1']=$this->Service_model->getservicereqDetailsbyid($id);
		   if(!empty($data['list1'])){
			   $data['list7']=$this->Service_model->getservicereqDetailsbyid($id);
		   }else{
			   $data['list7']=$this->Service_model->getservicereqDetailsbyid1($id);
		   }
		$data['getBranchservicereqbyid']=$this->Service_model->getBranchservicereqbyid($id);
		
		$data['list2']=$this->Service_model->getserviceEmpbyid($id);
		$data['list_serialnos']=$this->Service_model->list_serialnos();
		   
		$data['customerlist']=$this->Service_model->customerlist();
		   
		$data['servicecat_list']=$this->Service_model->print_servicecat_list($id);
		$data['problemlist']=$this->Service_model->print_problemlist($id);
		
		$data['problemlist1']=$this->Service_model->problemlist();
		
		$data['employee_list']=$this->Service_model->employee_list();
		$data['accessories_list']=$this->Service_model->accessories_list();
		
		$data['zone_pincodes']=$this->Service_model->zone_pincodes();
		
		
		$data1['user_dat'] = $this->session->userdata('login_data');
		$this->load->view('templates/header',$data1);
		$this->load->view('print_preview_request',$data);
    }
	
	
	public function print_preview(){ 
	
		$id=$this->input->post('url_id');
		
		$data['list']=$this->Service_model->getservicereqbyid($id);
		//$data['list1']=$this->Service_model->getservicereqDetailsbyid($id);
		
		$data['list1']=$this->Service_model->getservicereqDetailsbyid($id);
		   if(!empty($data['list1'])){
			   $data['list7']=$this->Service_model->getservicereqDetailsbyid($id);
		   }else{
			   $data['list7']=$this->Service_model->getservicereqDetailsbyid1($id);
		   }
		$data['getBranchservicereqbyid']=$this->Service_model->getBranchservicereqbyid($id);
		
		$data['list2']=$this->Service_model->getserviceEmpbyid($id);
		$data['list_serialnos']=$this->Service_model->list_serialnos();
		   
		$data['customerlist']=$this->Service_model->customerlist();
		   
		$data['servicecat_list']=$this->Service_model->print_servicecat_list($id);
		$data['problemlist']=$this->Service_model->print_problemlist($id);
		
		$data['problemlist1']=$this->Service_model->problemlist();
		
		$data['employee_list']=$this->Service_model->employee_list();
		$data['accessories_list']=$this->Service_model->accessories_list();
		
		$data['zone_pincodes']=$this->Service_model->zone_pincodes();
		
		$data['spare_replaced']=$this->input->post('spare_replaced');
		$data['spare_charge']=$this->input->post('spare_charge');
		$data['service_charge']=$this->input->post('service_charge');
		
		
		
		$data1['user_dat'] = $this->session->userdata('login_data');
		$this->load->view('templates/header',$data1);
		$this->load->view('print_preview_request',$data);
    }
	
	
	public function stamping_print_service(){ 
		$id=$this->uri->segment(3);
		
		$data['list']=$this->Service_model->getservicereqbyid($id);
		//$data['list1']=$this->Service_model->getservicereqDetailsbyid($id);
		
		$data['list1']=$this->Service_model->getservicereqDetailsbyid($id);
		   if(!empty($data['list1'])){
			   $data['list7']=$this->Service_model->getservicereqDetailsbyid($id);
		   }else{
			   $data['list7']=$this->Service_model->getservicereqDetailsbyid1($id);
		   }
		
		
		$data['list2']=$this->Service_model->getserviceEmpbyid($id);
		$data['list_serialnos']=$this->Service_model->list_serialnos();
		   
		$data['customerlist']=$this->Service_model->customerlist();
		   
		$data['servicecat_list']=$this->Service_model->print_servicecat_list($id);
		$data['problemlist']=$this->Service_model->print_problemlist($id);
		
		$data['stamping_details']=$this->Service_model->stamping_details($id);
		$data['problemlist1']=$this->Service_model->problemlist();
		
		$data['employee_list']=$this->Service_model->employee_list();
		$data['accessories_list']=$this->Service_model->accessories_list();
		
		
		
		
		$data1['user_dat'] = $this->session->userdata('login_data');
		$this->load->view('templates/header',$data1);
		$this->load->view('stamping_print_service',$data);
    }
	
	
	public function get_custbyid(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_customerdetails($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function searchByStatus(){
		$id=$this->input->post('id');
		$data1['user_dat'] = $this->session->userdata('login_data');
		$user_acc = $data1['user_dat'][0]->user_access;
		$user_type = $data1['user_dat'][0]->user_type;
		
		if(isset($user_acc) && $user_acc!=""){
			$user_access = $user_acc;
		}else{
			$user_access = "";
		}
		
		
		if(isset($id) && $id=="all"){
			$data['get_searchByStatus']=$this->Service_model->service_req_list($user_access,$user_type);
		}else{
			$data['get_searchByStatus'] = $this->Service_model->get_searchByStatus($id);
		}
		
		
		$data['service_req_list1']=$this->Service_model->service_req_list1($user_access,$user_type);
		$data['service_req_listforEmp']=$this->Service_model->service_req_listforEmp();
		
		$data['status_list']=$this->Service_model->status_list();
		$data['combine_status_list']=$this->Service_model->combine_status_list();
		   
		//$data1['user_dat'] = $this->session->userdata('login_data');
		//$this->load->view('templates/header',$data1);
		$this->load->view('search_service_req_list',$data);
		
    }
	
	
	public function get_cus(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_custo()));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	
	public function get_orderbyid(){
		$id=$this->input->post('serialno');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_orderdetails($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function get_orderbyid1(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_orderdetails1($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function get_servicecatbyid1(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_servicecatdetails1($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function get_probcatbyid1(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_probcatdetails1($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function get_servicecatbyid(){
		$id=$this->input->post('serialno');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_servicecatdetails($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function get_probcatbyid(){
		$id=$this->input->post('serialno');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_probcatdetails($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function addrow(){ 
		 $data['count']=$this->input->post('countid');
		 //echo "Count: ".$data['count'];
		$data['customerlist']=$this->Service_model->customerlist();
		$data['list_serialnos']=$this->Service_model->list_serialnos();
		$data['servicecat_list']=$this->Service_model->servicecat_list();
		$data['problemlist']=$this->Service_model->problemlist();
		$data['employee_list']=$this->Service_model->employee_list();
		
		 $this->load->view('add_service_req_row',$data);
    }
	
	public function update_service_req(){ 
			error_reporting(0);
		   $id=$this->uri->segment(3);
		   $data['list']=$this->Service_model->getservicereqbyid($id);
		   //$data['list1']=$this->Service_model->getservicereqDetailsbyid($id);
		   $data['getBranchservicereqbyid']=$this->Service_model->getBranchservicereqbyid($id);
		   
		   $data['list1']=$this->Service_model->getservicereqDetailsbyid($id);
		   if(!empty($data['list1'])){
			   $data['list7']=$this->Service_model->getservicereqDetailsbyid($id);
		   }else{
			   $data['list7']=$this->Service_model->getservicereqDetailsbyid1($id);
		   }
		   
		   $data['get_mods']=$this->Service_model->get_mods();
		   
		   $model_id = $data['list7'][0]->modelid;
		   
		   $data['list2']=$this->Service_model->getserviceEmpbyid($id);
		   $data['list_serialnos']=$this->Service_model->list_serialnos();
		   $data['service_typelist']=$this->Service_model->service_typelist();
		   
		   $data['customerlist']=$this->Service_model->customerlist();
		   
		   $data['servicecat_list']=$this->Service_model->servicecat_list();
		   $data['problemlist']=$this->Service_model->problemlist();
		   
		   $data['getProbByModel']=$this->Service_model->getProbByModel($model_id);
		   
		   $data['employee_list']=$this->Service_model->employee_list();
		   $data['accessories_list']=$this->Service_model->accessories_list();
		   
		   $data['stamping_details']=$this->Service_model->stamping_details($id);
		   
		   $data['get_cancel_reason']=$this->Service_model->get_cancel_reason($id);
		   
		   
		   $data1['user_dat'] = $this->session->userdata('login_data');
		   $this->load->view('templates/header',$data1);
		   $this->load->view('edit_service_req',$data);
		
    }
	
	public function update_service_status(){ 
		  $reqid=$this->input->post('reqid');
		 //$this->input->post('procatid');
		 
		 $data=array(
            'status'=>$this->input->post('statusid')
        );
		 $s = $this->Service_model->update_service_status($data,$reqid);
		
    }
	
	public function get_serials(){
		$id=$this->input->post('id');//echo $id; exit;
		//$cust_id=$this->input->post('cust_id');
		
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_serialdetails($id)));
		 
    }
	
	public function get_serialnos(){
		$id=$this->input->post('id');//echo $id; exit;
		$cust_id=$this->input->post('cust_id');
		
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_servicenodetails($id,$cust_id)));
		 
    }
	
	public function get_modelnos(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_modelnos($id)));
		 
    }
	
	
	public function edit_service_req(){ 
		
		date_default_timezone_set('Asia/Calcutta');
		$updated_on = date("Y-m-d H:i:s");
		
		$data111['user_dat'] = $this->session->userdata('login_data');
		$user_id = $data111['user_dat'][0]->id;
		
		
		$data=array(
            'request_id'=>$this->input->post('req_id'),
            'cust_name'=>$this->input->post('cust_name'),
			'br_name'=>$this->input->post('br_name'),
            'mobile'=>$this->input->post('mobile'),
			'email_id'=>$this->input->post('email_id'),
			'address'=>$this->input->post('address'),
			'address1'=>$this->input->post('address1'),
			'request_date'=>$this->input->post('datepicker'),
			'updated_on'=>$updated_on,
			'user_id'=>$user_id
        );
        $id=$this->input->post('servicereqid');
		$rowid=$this->input->post('servicereqdetailid');
		
		$this->Service_model->update_service_request($data,$id);
		
		if($id){
		$data1['request_id']=$id;
		$data1['serial_no']=$this->input->post('serial_no');
		$data1['batch_no']=$this->input->post('batch_no');
       
	    $data1['cat_id']=$this->input->post('categoryid');
        $data1['subcat_id']=$this->input->post('subcategoryid');
        $data1['brand_id']=$this->input->post('brandid');
        $data1['model_id']=$this->input->post('modelid');
        //$data1['warranty_date']=$this->input->post('warranty_date');
		
		if($this->input->post('warranty_date')!=""){
			$data1['warranty_date'] = $this->input->post('warranty_date');
		}else{
			$data1['warranty_date'] = "";
		}
		
        $data1['machine_status']=$this->input->post('machine_status');
				
		$data1['service_type']=$this->input->post('service_type');
		//$data1['service_cat']=$this->input->post('service_cat');
		$ser_det = $this->input->post('service_cat');
		$ser = explode("-",$ser_det);
		$data1['service_cat'] = $ser['0'];
		
		$data1['zone']=$this->input->post('locid');
		$data1['service_loc_coverage']=$this->input->post('service_loc_coverage');
		
		$proble=$this->input->post('probi');
		/* echo "<pre>";
		print_r($data1['problem']);
		exit; */
		if (is_array($proble)){
					$data1['problem']= implode(",",$proble);
				}else{
					$data1['problem']="";
				}
		//$data1['problem']=$this->input->post('prob');
		//$data1['assign_to']=$this->input->post('assign_to');
		$data1['service_priority']=$this->input->post('service_priority');
		$data1['blank_app']=$this->input->post('blank_app');
		
		 $emp_det = $this->input->post('assign_to');
		$emp = explode(",",$emp_det);
		$data1['assign_to'] = $emp['0']; 
		
		$data1['received']=$this->input->post('received');
		if (is_array($data1['received'])){
					$data1['received']= implode(",",$data1['received']);
				}else{
					$data1['received']="";
				}
		
		$data1['notes']=$this->input->post('notes');
		//$countids=$this->input->post('countids');
		/* echo "<pre>";
		print_r($data1);
		exit; */
		//$this->Service_model->delete_serv_req_details($id);
		//$result1=$this->Service_model->add_service_details($data1);

		$where = "id=".$rowid." AND request_id=".$id; 
		$result1=$this->Service_model->update_service_details($data1,$where);		
		}
		echo "<script>alert('Service Request Updated');window.location.href='".base_url()."pages/service_req_list';</script>";
    
    }
	
	public function get_branchbyid(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_branchdetails($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	public function get_cust_servicezone(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_servicezone($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	public function get_branchname(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Service_model->get_branch($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function searchBycustomer()
	{
		$search=$this->input->post('username');
		//echo $search;exit; 
		$drop=$this->input->post('pwd');
		if($drop && $search)
		{
		
		$data['customer']=$this->Service_model->customer_list($search,$drop);
		$data['stat_list']=$this->Service_model->status_list();
		//$data['get_searchByStatus']=$this->Service_model->service_req_list($search);
		}
		else
		{
			
			$data['customer']=$this->Service_model->getallreq_list($search);
			$data['stat_list']=$this->Service_model->status_list();
		}
		$this->load->view('service_list',$data);
		
	}
	
	
	
    public function getsub_category(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->getsub_cat($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	  
	public function get_brand(){
		$subcatid=$this->input->post('subcatid');//echo $id; exit;
		$categoryid=$this->input->post('categoryid');
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_brands($categoryid,$subcatid)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
    
	public function get_model(){
		$subcatid=$this->input->post('subcatid');//echo $id; exit;
		$categoryid=$this->input->post('categoryid');
		$brandid=$this->input->post('brandid');
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_models($categoryid,$subcatid,$brandid)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
    
    
	
	public function del_order(){ 
		 $id=$this->input->post('id');
		 $this->Order_model->delete_order_details($id);
		$result = $this->Order_model->delete_orders($id);
    }
    
}