<?php 
class Accessories_model extends CI_Model{
function __construct(){
parent::__construct();
$this->load->database();
}
    public function add_accessory($data){
     $this->db->insert('accessories',$data);
    return true;     
      
    }
	
	public function accessories_list(){
        $this->db->select("id,accessory",FALSE);
		$this->db->from('accessories'); 
		$query = $this->db->get();
        return $query->result();
    }
	public function update_accessory($data,$id){ 
        $this->db->where('id',$id); 
		echo $this->db->update('accessories',$data);exit;
    }
	public function del_accessory($id){
        $this->db->where('id',$id);
        $this->db->delete('accessories');
    }
	
}