<?php 
class order extends CI_Controller{

    function __construct(){
     parent::__construct();
    $this->load->helper('url');
    $this->load->model('Order_model');

    }
    
    
    public function add_order(){ //echo "<pre>";print_r($_POST);exit;
		
        $data['order_id']=$this->input->post('order_no');
		$data['customer_id']=$this->input->post('cust_name');
		$data['customer_service_loc_id']=$this->input->post('br_name');
		$data['contact_name']=$this->input->post('cont_name');
		$data['mobile']=$this->input->post('mobile');
		$data['email_id']=$this->input->post('email');
		$data['address']=$this->input->post('addr');
		$data['city']=$this->input->post('city');
		$data['state']=$this->input->post('state');
		$data['pincode']=$this->input->post('pincode');
		$data['zone_coverage']=$this->input->post('service_loc_coverage');
		
		date_default_timezone_set('Asia/Calcutta');
		$data['created_on'] = date("Y-m-d H:i:s");
		$data['updated_on'] = date("Y-m-d H:i:s");
		
		$data111['user_dat'] = $this->session->userdata('login_data');
		$data['user_id'] = $data111['user_dat'][0]->id;
		
		$result=$this->Order_model->add_orders($data);
		//$res = sprintf("%05d", $result);
		
		if($result){
			$data1['order_id']=$result;
			$data1['serial_no']=$this->input->post('serial_no');
			$data1['batch_no']=$this->input->post('batch_no');
			
            $data1['cat_id']=$this->input->post('category');
            $data1['subcat_id']=$this->input->post('subcategory');
            $data1['brand_id']=$this->input->post('brandname');
            $data1['model_id']=$this->input->post('model');
            //$data1['price']=$this->input->post('price');
            $data1['service_loc_id']=$this->input->post('service_loc');
		    $data1['purchase_date']=$this->input->post('purchase');
			
			 $colorRadio=$this->input->post('colorRadio');	
			
			if($colorRadio=='paid'){
				$data1['paid']=$this->input->post('colorRadio');
			}elseif($colorRadio=='warranty'){
				$data1['warranty_date']=$this->input->post('warranty');
			}elseif($colorRadio=='prevent'){
				$data1['prev_main']=$this->input->post('preventive_main');
				$data1['prev_main_updated']=$this->input->post('purchase');
				$data1['prenos']=$this->input->post('prenos');
			}else{
					$data1['amc_type']=$this->input->post('amc_type');
					$data1['amc_start_date']=$this->input->post('amc_start_date');
					$data1['amc_end_date']=$this->input->post('amc_end_date');
					$data1['prev_main_updated']=$this->input->post('amc_start_date');
					$data1['prenos']=$this->input->post('amc_prenos');
			}
			
			
			$data1['notes']=$this->input->post('notes');
			
			$result1=$this->Order_model->add_order_details($data1);
			
			if($colorRadio=='amc'){
				echo "<script>alert('Order Updated');window.location.href='".base_url()."pages/amc_list';</script>";
			}else if($colorRadio=='warranty' || $colorRadio=='prevent'){
				echo "<script>alert('Order Updated');window.location.href='".base_url()."pages/order_list';</script>";
			}else{
				echo "<script>alert('Order Updated');window.location.href='".base_url()."pages/expiry_closed';</script>";
			}
    }
	
    }
	
	
	public function add_quick_order(){ //echo "<pre>";print_r($_POST);exit;
		$data['order_id']=$this->input->post('order_no');
		$data['customer_id']=$this->input->post('cust_name');
		$data['customer_service_loc_id']=$this->input->post('br_name');
		$data['contact_name']=$this->input->post('cont_name');
		$data['mobile']=$this->input->post('mobile');
		$data['email_id']=$this->input->post('email');
		$data['address']=$this->input->post('addr');
		$data['city']=$this->input->post('city');
		$data['state']=$this->input->post('state');
		$data['pincode']=$this->input->post('pincode');
		$data['zone_coverage']=$this->input->post('service_loc_coverage');
		
		date_default_timezone_set('Asia/Calcutta');
		$data['created_on'] = date("Y-m-d H:i:s");
		$data['updated_on'] = date("Y-m-d H:i:s");
		
		$data111['user_dat'] = $this->session->userdata('login_data');
		$data['user_id'] = $data111['user_dat'][0]->id;
		
		$result=$this->Order_model->add_orders($data);
		//$res = sprintf("%05d", $result);
		
		$serial_nos = $this->input->post('serial_no');
		
		if(!empty($serial_nos)){
				for($i=0;$i<count($serial_nos);$i++){
					$data1['order_id']=$result;
					$data1['serial_no']=$this->input->post('serial_no')[$i];
					$data1['cat_id']=$this->input->post('category')[$i];
					$data1['subcat_id']=$this->input->post('subcategory')[$i];
					$data1['brand_id']=$this->input->post('brandname')[$i];
					$data1['model_id']=$this->input->post('model')[$i];
					//$data1['price']=$this->input->post('price');
					$data1['service_loc_id']=$this->input->post('service_loc')[$i];
					$data1['purchase_date']=$this->input->post('purchase')[$i];
					
					 $colorRadio=$this->input->post('colorRadio');	
					
					if($colorRadio=='paid'){
						$data1['paid']=$this->input->post('colorRadio');
					}elseif($colorRadio=='warranty'){
						$data1['warranty_date']=$this->input->post('warranty');
					}else{
						$data1['prev_main']=$this->input->post('preventive_main');
						$data1['prenos']=$this->input->post('prenos');
					}
					$data1['notes']=$this->input->post('notes');
					
					$result1=$this->Order_model->add_order_details($data1);
					echo "<script>parent.$.fancybox.close();</script>";
				}
			
    }
	
    }
	
	
	public function add_sales_quick(){ 
		$data1['customerlist']=$this->Order_model->customerlist();
		$data1['prodcatlist']=$this->Order_model->prod_cat_dropdownlist();
		//$data1['subcatlist']=$this->Order_model->prod_sub_cat_dropdownlist();
		///$data1['brandlist']=$this->Order_model->brandlist();
		$data1['modellist']=$this->Order_model->modellist();
		
		$data1['serial_cnt']=$this->Order_model->serial_cnt();
		
		if(empty($data1['serial_cnt'])){
			$data1['cnt']='0000001';
		}else{
			$dddd = $data1['serial_cnt'][0]->serial_no; 
			$cusid = substr($dddd,3,8);
			$dat= $cusid + 1;
			$data1['cnt']=sprintf("%07d", $dat);
		}
		
		
		$data1['serviceLocList']=$this->Order_model->serviceLocList();
		
		date_default_timezone_set('Asia/Calcutta');
		$data1['saledate'] = date("Y-m-d H:i:s");
		
		$warranty_date = new DateTime("+12 months");
		$dd = $warranty_date->format('Y-m-d') . "\n";
		$newdate = strtotime ( '-1 day' , strtotime ($dd)) ;
		$data1['warranty_date'] =  date ( 'Y-m-d H:i:s' , $newdate ); 
		
		//$data1['user_dat'] = $this->session->userdata('login_data');
		//$this->load->view('templates/header',$data1);
		$this->load->view('add_sales_quick',$data1);
    }
	
	public function addrow_sales(){ 
		 $data['count']=$this->input->post('countid');
		
		 $data['service_loc_name']=$this->input->post('service_loc_name');
		 $data['service_loc']=$this->input->post('service_loc');
		 
		 //echo "Count: ".$data['count'];
		date_default_timezone_set('Asia/Calcutta');
		$data['saledate'] = date("Y-m-d");
		
		$warranty_date = new DateTime("+12 months");
		$dd = $warranty_date->format('Y-m-d') . "\n";
		$newdate = strtotime ('-1 day' , strtotime ($dd));
		$data['warranty_date'] =  date('Y-m-d' , $newdate); 
		
		$sr_no = $this->input->post('sr_no');
		
		$dddd = $sr_no; 
		$cusid = substr($dddd,3,8);
		$dat= $cusid + 1;
		$data['cnt']=sprintf("%07d", $dat);
		
		 
		$data['customerlist']=$this->Order_model->customerlist();
		$data['prodcatlist']=$this->Order_model->prod_cat_dropdownlist();
		$data['serviceLocList']=$this->Order_model->serviceLocList();
		//$data['batch_nos']=$this->Order_model->batch_nos();
		$data['modellist']=$this->Order_model->modellist();
		
		 $this->load->view('addrow_sales',$data);
    }
	
	public function get_probcatbyid1(){
		$id=$this->input->post('modelno');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_probcatdetails1($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	public function get_servicecatbyid1(){
		$id=$this->input->post('modelno');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_servicecatdetails1($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function get_branchname(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_branch($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function get_cust_servicezone(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_servicezone($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	
	public function get_productinfobyid(){
		$id=$this->input->post('modelno');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_productdetbyid($id)));
		
    }
	
	public function get_branchbyid(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_branchdetails($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	public function update_warrantydate(){
		$sale_date=$this->input->post('sale_date');
		
		$prev_date = date('Y-m-d', strtotime("+12 months", strtotime($sale_date)));
		echo $actual_date = date('Y-m-d', strtotime("-1 day", strtotime($prev_date)));
		
		/* $this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_branch($sale_date))); */
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	
	public function update_stats(){ 
		  $id=$this->input->post('id');
		 //$this->input->post('procatid');
		 
		 $data=array(
			'paid'=>$this->input->post('status')
        );
		 $s = $this->Order_model->update_status($data,$id);
		 echo "<span style='color:#666666;font-weight:bold;text-align:center;'>Order closed<span>";
		
    }
	
	public function edit_amc_update(){ 
		 $amc_typ = $this->input->post('amc_type');
		 
		 $data=array(
			'paid'=>"",
            'amc_start_date'=>$this->input->post('amc_start_date'),
            'amc_type'=>$this->input->post('amc_type'),
            'amc_end_date'=>$this->input->post('amc_end_date'),
			'prenos'=>$this->input->post('amcprenos'),
			'prev_main_updated'=>$this->input->post('amc_start_date')
        );
        $id=$this->input->post('orderid');
		
		$this->Order_model->update_amc($data,$id);
		//echo "<span style='color:#666666;font-weight:bold;text-align:center;'>AMC Updated<span>";
		echo "successfully updated";
	}
	
    public function getsub_category(){
		$id=$this->input->post('id');//echo $id; exit;
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->getsub_cat($id)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
	  
	public function get_brand(){
		$subcatid=$this->input->post('subcatid');//echo $id; exit;
		$categoryid=$this->input->post('categoryid');
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_brands($categoryid,$subcatid)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
    
	public function get_model(){
		$subcatid=$this->input->post('subcatid');//echo $id; exit;
		$categoryid=$this->input->post('categoryid');
		$brandid=$this->input->post('brandid');
		$this->output
           ->set_content_type("application/json")
           ->set_output(json_encode($this->Order_model->get_models($categoryid,$subcatid,$brandid)));
		   
		
		//$query=$this->Product_model->getsub_cat($id);
        //return $query;
    }
    
    public function update_order(){ 
		   $id=$this->uri->segment(3);
		   $data['list']=$this->Order_model->getorderbyid($id);
		   $data['list1']=$this->Order_model->getOrderDetailsbyid($id);
		   
		   $data['customerlist']=$this->Order_model->customerlist();
		   $data['prodcatlist']=$this->Order_model->prod_cat_dropdownlist();
		   $data['subcatlist']=$this->Order_model->prod_sub_cat_dropdownlist();
		   $data['brandlist']=$this->Order_model->brandlist();
		   
		   $data['modellist']=$this->Order_model->modellist();
		
		   $data['serviceLocList']=$this->Order_model->serviceLocList();
		   
		   $warranty_date = new DateTime("+12 months");
		   $data['warranty_date'] = $warranty_date->format('Y-m-d') . "\n";
		   
		   
		   $data1['user_dat'] = $this->session->userdata('login_data');
		$this->load->view('templates/header',$data1);
		   $this->load->view('edit_order_list',$data);
		
    }
	
	
	//view
	public function view_order()
	{
		   $id=$this->uri->segment(3);
		   $data['list']=$this->Order_model->getorderbyid($id);
		   $data['list1']=$this->Order_model->getOrderDetailsbyid($id);
		   
		   $data['customerlist']=$this->Order_model->customerlist();
		   $data['prodcatlist']=$this->Order_model->prod_cat_dropdownlist();
		   $data['subcatlist']=$this->Order_model->prod_sub_cat_dropdownlist();
		   $data['brandlist']=$this->Order_model->brandlist();
		   
		   $data['modellist']=$this->Order_model->modellist();
		
		   $data['serviceLocList']=$this->Order_model->serviceLocList();
		   
		   $warranty_date = new DateTime("+12 months");
		   $data['warranty_date'] = $warranty_date->format('Y-m-d') . "\n";
		   
		   
		   $data1['user_dat'] = $this->session->userdata('login_data');
		$this->load->view('templates/header',$data1);
		   $this->load->view('view_amclist',$data);
	}
	
	public function edit_order(){ 
	
		date_default_timezone_set('Asia/Calcutta');
		$updated_on = date("Y-m-d H:i:s");
		
		$data111['user_dat'] = $this->session->userdata('login_data');
		$user_id = $data111['user_dat'][0]->id;
		 
		 $data=array(
            'order_id'=>$this->input->post('order_no'),
            'customer_id'=>$this->input->post('cust_name'),
            'customer_service_loc_id'=>$this->input->post('br_name'),
			'contact_name'=>$this->input->post('cont_name'),
            'mobile'=>$this->input->post('mobile'),
            'email_id'=>$this->input->post('email'),
			'address'=>$this->input->post('addr'),
			'city'=>$this->input->post('city'),
			'state'=>$this->input->post('state'),
			'pincode'=>$this->input->post('pincode'),
			'zone_coverage'=>$this->input->post('service_loc_coverage'),
			'updated_on'=>$updated_on,
			'user_id'=>$user_id
        );
        $id=$this->input->post('orderid');
		
		$this->Order_model->update_orders($data,$id);
		
		//$this->Order_model->delete_order_details($id);
		
		$rowid=$this->input->post('orderdetailid'); 
		
		if($id){
			$data1['order_id']=$id;
			$data1['serial_no']=$this->input->post('serial_no');
			$data1['batch_no']=$this->input->post('batch_no');
            $data1['cat_id']=$this->input->post('category');
            $data1['subcat_id']=$this->input->post('subcategory');
            $data1['brand_id']=$this->input->post('brandname');
            $data1['model_id']=$this->input->post('model');
            //$data1['price']=$this->input->post('price');
            $data1['service_loc_id']=$this->input->post('service_loc');
		    $data1['purchase_date']=$this->input->post('purchase');
			
			 $colorRadio=$this->input->post('colorRadio');
			
			if($colorRadio=='paid'){
				$data1['paid']=$this->input->post('colorRadio');
				$data1['warranty_date']="";
				$data1['prev_main']="";
				
				$data1['amc_type']="";
				$data1['prev_main_updated']="";
				$data1['amc_start_date']="";
				$data1['amc_end_date']="";
				
				
				if($this->input->post('amc_type')!="" && $this->input->post('amc_prenos')!=""){
						$data1['prenos']="";
					}
			}elseif($colorRadio=='warranty'){
				$data1['warranty_date']=$this->input->post('warranty');
				$data1['paid']="";
				$data1['prev_main']="";
				
				$data1['amc_type']="";
				$data1['prev_main_updated']="";
				$data1['amc_start_date']="";
				$data1['amc_end_date']="";
				$data1['prenos']="";
				
			}elseif($colorRadio=='prevent'){
				$data1['paid']="";
					$data1['warranty_date']="";
					
					$data1['amc_type']="";
					$data1['amc_start_date']="";
					$data1['amc_end_date']="";
					
					$data1['prev_main']=$this->input->post('preventive_main');
					$data1['prev_main_updated']=$this->input->post('purchase');
					$data1['prenos']=$this->input->post('prenos');
					
			}else{
						$data1['amc_type']=$this->input->post('amc_type');
						$data1['prev_main_updated']=$this->input->post('amc_start_date');
						$data1['amc_start_date']=$this->input->post('amc_start_date');
						$data1['amc_end_date']=$this->input->post('amc_end_date');
						if($this->input->post('amc_type')!="" && $this->input->post('amc_prenos')!=""){
							$data1['prenos']=$this->input->post('amc_prenos');
						}else{
							$data1['prenos']=$this->input->post('prenos');
						}
						
						if($this->input->post('warranty_date_hide')!=""){
							$data1['warranty_date']="";
						}
						
						if($this->input->post('prev_main_hide')!=""){
							$data1['prev_main']="";
						}
						
						if($this->input->post('paid_hide')!=""){
							$data1['paid']="";
						}
				
			}
			
			
			$data1['notes']=$this->input->post('notes');
			
			//$result1=$this->Order_model->add_order_details($data1);
			
			$where = "id=".$rowid." AND order_id=".$id; 
		    $result1=$this->Order_model->Update_order_details($data1,$where);
		   
			if($colorRadio=='amc'){
				echo "<script>alert('Order Updated');window.location.href='".base_url()."pages/amc_list';</script>";
			}else if($colorRadio=='warranty' || $colorRadio=='prevent'){
				echo "<script>alert('Order Updated');window.location.href='".base_url()."pages/order_list';</script>";
			}else{
				echo "<script>alert('Order Updated');window.location.href='".base_url()."pages/expiry_closed';</script>";
			}
    }
		
    
    }
	
	public function update_amc_type()
	{ 
		$data['orderid'] = $this->uri->segment(3);
		$data['amc_type'] = $this->uri->segment(4);
		$data['todaydate'] = date("Y-m-d");
		
		$end_date = new DateTime("+12 months");
		$dd = $end_date->format('Y-m-d') . "\n";
		$newdate = strtotime ( '-1 day' , strtotime ($dd)) ;
		$data['end_date'] =  date ( 'Y-m-d' , $newdate ); 
		
		$this->load->view('amc_update',$data);
		
    }
	
	
	public function addrow(){ 
		 $data['count']=$this->input->post('countid');
		 //echo "Count: ".$data['count'];
		 date_default_timezone_set('Asia/Calcutta');
		$data['saledate'] = date("Y-m-d");
		 
		$data['customerlist']=$this->Order_model->customerlist();
		$data['prodcatlist']=$this->Order_model->prod_cat_dropdownlist();
		$data['serviceLocList']=$this->Order_model->serviceLocList();
		
		 $this->load->view('add_order_row',$data);
    }
	
	
	public function del_order(){ 
		 $id=$this->input->post('id');
		 $this->Order_model->delete_order_details($id);
		$result = $this->Order_model->delete_orders($id);
    }
    
}